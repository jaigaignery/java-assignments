import java.util.ArrayList;
public class ElectronicStore {
    String name;
    ArrayList<Desktop> listD;
    ArrayList<Laptop> listL;
    ArrayList<Fridge> listF;
    public ArrayList<String> listStr;

    public ElectronicStore(String name) {
        this.name = name;
        Desktop d1 = new Desktop(3.9, 16, 2000, false);
        Desktop d2 = new Desktop(4.4, 32, 1000, true);
        Desktop d3 = new Desktop(3.8, 16, 750, true);
        Laptop l1 = new Laptop(3.6, 8, 500, false, 15);
        Laptop l2 = new Laptop(4.0, 16, 256, true, 13);
        Laptop l3 = new Laptop(3.9, 32, 500, true, 17);
        Fridge f1 = new Fridge(15.6, true, "white");
        Fridge f2 = new Fridge(10.5, false, "grey");
        Fridge f3 = new Fridge(13.5, true, "black");
        listD = new ArrayList<>();
        listL = new ArrayList<>();
        listF = new ArrayList<>();
        listStr = new ArrayList<>();
        listD.add(d1);
        listD.add(d2);
        listD.add(d3);
        listL.add(l1);
        listL.add(l2);
        listL.add(l3);
        listF.add(f1);
        listF.add(f2);
        listF.add(f3);
        for (int i = 0; i<listD.size();i++) {
            listStr.add(listD.get(i).toString());
        }
        for (int i = 0; i<listL.size();i++) {
            listStr.add(listL.get(i).toString());
        }
        for (int i = 0; i<listF.size();i++) {
            listStr.add(listF.get(i).toString());
        }
    }
    public void printStock() {
        System.out.println("The items in stock at "+name+" are:");
        for (int i = 0; i < listStr.size(); i++) {
            System.out.println(listStr.get(i));
        }
    }
    public boolean searchStock(String keyword) {
        for (int i = 0; i < listStr.size(); i++) {
            if ((listStr.get(i).toLowerCase()).contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }
}

