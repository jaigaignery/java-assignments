import java.util.Scanner;
public class ElectronicStoreTester{
    public static void main(String[] args) {
        ElectronicStore store = new ElectronicStore("Gaignery's Gadgets");
        store.printStock();
        Scanner input = new Scanner(System.in);
        while (true){
            System.out.println("\nPlease enter your keyword below.");
            String keyword = input.nextLine();
            if (keyword.equals("quit")){
                System.out.println("Thanks for shopping at "+store.name+"!");
                break;
            }else if (store.searchStock(keyword)) {
                System.out.println("A matching item is contained in the store's stock.");
            }else{
                System.out.println("No items in the store's stock match that term.");
            }
        }
    }
}
