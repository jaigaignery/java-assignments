public class Laptop {
    double cpuSpeed;
    int ram;
    int storage;
    boolean ssd;
    int screenSize;

    public Laptop(double cpuSpeed, int ram, int storage, boolean ssd, int screenSize) {
        this.cpuSpeed = cpuSpeed;
        this.ram = ram;
        this.storage = storage;
        this.ssd = ssd;
        this.screenSize = screenSize;
    }
    public String toString(){
        String ssdT=String.valueOf(ssd);
        if (ssdT=="true"){
            ssdT = "SSD";
        }else{
            ssdT = "HDD";
        }

        return screenSize+" inch laptop PC with a "+cpuSpeed+"GHz processor, "+ram+"GB of RAM, and "+storage+"GB of "+ssdT+" storage.";
    }
}