public class Desktop {
    double cpuSpeed;
    int ram;
    int storage;
    boolean ssd;

    public Desktop(double cpuSpeed, int ram, int storage, boolean ssd) {
        this.cpuSpeed = cpuSpeed;
        this.ram = ram;
        this.storage = storage;
        this.ssd = ssd;
    }
    public String toString(){
        String ssdT=String.valueOf(this.ssd);
        if (ssdT=="true"){
            ssdT = "SSD";
        }else{
            ssdT = "HDD";
        }

        return "Desktop PC with a "+cpuSpeed+"GHz processor, "+ram+"GB of RAM, and "+storage+"GB of "+ssdT+" storage.";
    }
}
