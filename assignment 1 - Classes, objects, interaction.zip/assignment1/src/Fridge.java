public class Fridge {
    double size;
    boolean freezer;
    String colour;

    public Fridge(double size, boolean freezer, String colour) {
        this.size = size;
        this.freezer = freezer;
        this.colour = colour;
    }
    public String toString(){
        String freeze=String.valueOf(freezer);
        if (freeze=="true"){
            freeze = "with a freezer ";
        }else{
            freeze = "";
        }

        return size+" cubic foot fridge "+freeze+"in "+colour+".";
    }
}